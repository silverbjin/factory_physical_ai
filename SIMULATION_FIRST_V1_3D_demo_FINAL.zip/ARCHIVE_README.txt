Simulation First Gazebo3D demo1.6 verified overlay.
Requires existing repository, ROS2 Jazzy/Gazebo Harmonic, virtual environment and Fuel resources.
Includes corrected demo_3d, final_validation and diagnostic evidence. Accepted canonical files are not included or overwritten.
Extract to a staging directory first; replace the old demo_3d directory with this one so obsolete bin/gz and verifier files are not retained. Preserve earlier proof before selecting a new output directory.
Run commands are in demo_3d/3D_DEMO_GUIDE.md.
Proof includes actual rendering, real mission success, all gates A-H, bounded cleanup and unchanged canonical files.
DEMO_VISUALIZATION_AUGMENTATION and DEMO_MIDDLEWARE_ADAPTATION are additional to frozen accepted Evidence; no new canonical acceptance.
